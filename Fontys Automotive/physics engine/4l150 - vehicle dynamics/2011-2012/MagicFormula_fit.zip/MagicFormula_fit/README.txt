This demo program assumes that the MATLAB Optimisation Toobox is installed

You can check this by typing "ver" at the MATLAB command prompt:

>> ver
-------------------------------------------------------------------------------------
MATLAB Version 7.5.0.342 (R2007b)
MATLAB License Number: 284992
Operating System: Microsoft Windows XP Version 5.1 (Build 2600: Service Pack 3)
Java VM Version: Java 1.6.0 with Sun Microsystems Inc. Java HotSpot(TM) Client VM mixed mode
-------------------------------------------------------------------------------------
MATLAB                                                Version 7.5        (R2007b)
Simulink                                              Version 7.0        (R2007b)
Control System Toolbox                                Version 8.0.1      (R2007b)
Optimization Toolbox                                  Version 3.1.2      (R2007b)       <- optimsation toolbox is present!
Signal Processing Blockset                            Version 6.6        (R2007b)
Signal Processing Toolbox                             Version 6.8        (R2007b)
SimMechanics                                          Version 2.7        (R2007b)
Simscape                                              Version 2.0        (R2007b)
Stateflow                                             Version 7.0        (R2007b)
Virtual Reality Toolbox                               Version 4.6        (R2007b)


