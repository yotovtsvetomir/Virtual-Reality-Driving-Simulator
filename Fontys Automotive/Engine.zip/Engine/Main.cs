using System;

namespace CarPhysicsEngine
{
    internal class MainClass
    {
        public static void Main(String[] args)
        {
            
        }
    }
}