﻿using System;
using CarPhysicsEngine.Turning;
using UnityEngine;

namespace CarPhysicsEngine
{
    public class CarBehaviour : MonoBehaviour
    {
        /// <summary>
        ///     Percentage input from throttle pedal (0 - 100)
        /// </summary>
        public double ThrottleInput
        {
            get { return throttleInput; }
            set { throttleInput = Helpers.SaturationDynamic(0, 100, value); }
        }
        private double throttleInput;

        /// <summary>
        ///     Percentage input from brake pedal (0 - 100)
        /// </summary>
        public double BrakeInput
        {
            get { return brakeInput; }
            set { brakeInput = Helpers.SaturationDynamic(0, 100, value); }
        }
        private double brakeInput;

        /// <summary>
        ///     Input from steering wheel  [angle-radians]
        /// </summary>
        public double SteerAngle
        {
            get { return steerAngle; }
            set
            {
                const double angleRadiansLimit = 0.733038285837618D; // (720/17) * (π/180)

                steerAngle = Helpers.SaturationDynamic(-angleRadiansLimit, angleRadiansLimit, value);
            }
        }
        private double steerAngle;

        /// <summary>
        ///     Real-world position of car's centre
        /// </summary>
        public double XCoordinate { get; private set; }

        /// <summary>
        ///     Real-world position of car's centre
        /// </summary>
        public double YCoordinate { get; private set; }

        /// <summary>
        ///     Change in time between frames [seconds]
        /// </summary>
        public double DeltaT
        {
            get { return (currentDateTime - previousDateTime).TotalSeconds; }
        }
        private DateTime previousDateTime;
        private DateTime currentDateTime;

        /// <summary>
        ///     Current Forward Velocity [m/s]
        /// </summary>
        public double ForwardVelocity { get; private set; }

        /// <summary>
        ///     Stores the yaw velocity of the previous iteration
        /// </summary>
        private double previousYawVelocity;

        private double YawAngle { get; set; }

        private float startX;
        private float startY;

        private Tyre tyre;
        public Forces Forces;
        public Movement Movement;
        public Position Position;
        public Acceleration.Acceleration Acceleration;

        public void Start()
        {
            previousYawVelocity = 0;
            ForwardVelocity = 22.22;
            ThrottleInput = 0;
            BrakeInput = 0;

            YawAngle = 0;
            SteerAngle = 0;

            currentDateTime = previousDateTime = DateTime.Now;


            startX = transform.position.x;
            startY = transform.position.y;
            XCoordinate = YCoordinate = 0;

            tyre = new Tyre();
            Forces = new Forces();
            Movement = new Movement();
            Position = new Position();
            Acceleration = new Acceleration.Acceleration();
        }

        public void Update()
        {
            OnKeyPress();

            // Acceleration is run before Turning because we need forward velocity
            //CalculateAcceleration();

            // Forward Velocity needs to be greater than 0 to compute Alpha Front/Rear
            if (!ForwardVelocity.Equals(0))
            {
                CalculateTurning();
            }
            var newX = startX + (float)XCoordinate;
            var newY = startY + (float)YCoordinate;

            transform.position = new Vector3(newX, 0, 0);

            Debug.Log("UNITY SUX 100 --- X: " + newX + "; Y: " + newY);

            previousDateTime = currentDateTime;
            currentDateTime = DateTime.Now;
        }

        private void CalculateAcceleration()
        {
            Acceleration.ThrottleInput = ThrottleInput;
            Acceleration.BrakeInput = BrakeInput;
            Acceleration.ForwardVelocityInput = ForwardVelocity;
            Acceleration.DeltaT = DeltaT;

            ForwardVelocity = Acceleration.Run();
        }

        private void CalculateTurning()
        {
            // Initialize the properties in Tyre
            tyre.ForwardVelocity = ForwardVelocity;
            tyre.SteerAngle = SteerAngle;
            tyre.LateralVelocity = Movement.LateralVelocity();
            tyre.YawVelocity = Movement.YawVelocity();

            // Initialize the properties in Forces
            Forces.TyreForceFront = tyre.TyreForceFront();
            Forces.TyreForceRear = tyre.TyreForceRear();

            // Initialize the properties in Movement
            Movement.FyTotal = Forces.FyTotal();
            Movement.MzTotal = Forces.MzMoment();
            Movement.DeltaT = DeltaT;
            Movement.ForwardVelocity = ForwardVelocity;

            // Initialize the properties in Position
            previousYawVelocity = Position.YawVelocity = Movement.YawVelocity();
            Position.LateralVelocity = Movement.LateralVelocity();
            Position.DeltaT = DeltaT;
            Position.ForwardVelocity = ForwardVelocity;
            Position.YawAngle = YawAngle;

            Position.YawVelocityIntegral();
            // Calculate the new world coordinates for the vehicle
            XCoordinate += Position.VehicleDisplacementX();
            YCoordinate += Position.VehicleDisplacementY();

            //Set previous movement values
            Movement.PreviousLateralVelocity = Movement.LateralVelocity();
            Movement.PreviousYawVelocity = previousYawVelocity;

            YawAngle += DeltaT * Movement.YawVelocity();
        }

        private void OnKeyPress()
        {
            const double deltaAngle = 0.02;
            const double deltaThrottle = 10;
            const double deltaBrake = 10;

            if (Input.GetKeyDown(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
            {
                ThrottleInput -= deltaThrottle;
            }
            else if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
            {
                Debug.Log("Moving Forward");
                ThrottleInput += deltaThrottle;
            }
            else if (Input.GetKeyDown(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
            {
                SteerAngle += deltaAngle;
            }
            else if (Input.GetKeyDown(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
            {
                SteerAngle -= deltaAngle;
            }
            else if (Input.GetKeyDown(KeyCode.Q))
            {
                BrakeInput -= deltaBrake;
            }
            else if (Input.GetKeyDown(KeyCode.E))
            {
                BrakeInput += deltaBrake;
            }
        }
    }
}